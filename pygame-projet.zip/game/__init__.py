"""Package de base du jeu Pygame."""
